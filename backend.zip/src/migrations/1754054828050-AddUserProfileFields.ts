import { MigrationInterface, QueryRunner } from "typeorm";

export class AddUserProfileFields1754054828050 implements MigrationInterface {
    name = 'AddUserProfileFields1754054828050'

    public async up(queryRunner: QueryRunner): Promise<void> {
        // This migration is a duplicate of the previous one and has been intentionally left empty.
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        // This migration is a duplicate of the previous one and has been intentionally left empty.
    }

}
