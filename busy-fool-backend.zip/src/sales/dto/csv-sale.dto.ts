export class CsvSaleDto {
  productName: string;
  quantitySold: number;
  salePrice: number;
  saleDate: Date;
}
